#include <iostream>

int main() {
  std::cout << "My app" << std::endl;
  return 0;
}

