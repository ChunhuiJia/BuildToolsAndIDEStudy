
namespace my_lib {
    int sum( int left, int right );
}
