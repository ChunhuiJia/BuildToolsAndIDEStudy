package com.example;

public class Greeting {
    public static void sayHi() {
        System.out.println("Hi!");
    }
}
