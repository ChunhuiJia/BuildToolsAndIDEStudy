int number() {
  return 42;
}
